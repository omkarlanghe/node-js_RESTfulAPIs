using System;
using System.Runtime.Serialization;


namespace aspnetcoreDemo1.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
        //Methods added on friday 
        /*public int id {
            get;
            set;
        }

        public string productName {
            get;
            set;
        }

        public int price {
            get;
            set;
        }

        public bool available {
            get;
            set;
        }*/
    }
}
namespace aspnetcoreDemo1.Models
{
    public class Product {
        public int id {
            get;
            set;
        }
        public string productName {
            get;
            set;
        }

        public int price {
            get;
            set;
        }
        public bool available {
            get;
            set;
        }
    }
}